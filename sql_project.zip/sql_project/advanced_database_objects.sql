-- View for today's appointments
CREATE VIEW vw_TodaysAppointments AS
SELECT a.AppointmentID, d.DoctorName, p.PatientName, a.AppointmentTime
FROM Appointments a
JOIN Doctors d ON a.DoctorID = d.DoctorID
JOIN Patients p ON a.PatientID = p.PatientID
WHERE a.AppointmentDate = CURDATE();

-- Stored procedure to get appointments by doctor
DELIMITER //
CREATE PROCEDURE sp_GetDoctorAppointments(IN doc_id INT)
BEGIN
    SELECT a.AppointmentID, p.PatientName, a.AppointmentDate, a.AppointmentTime
    FROM Appointments a
    JOIN Patients p ON a.PatientID = p.PatientID
    WHERE a.DoctorID = doc_id
    ORDER BY a.AppointmentDate, a.AppointmentTime;
END //
DELIMITER ;

-- Stored procedure to create invoice for appointment
DELIMITER //
CREATE PROCEDURE sp_CreateInvoiceForAppointment(IN app_id INT, IN amount DECIMAL(10,2))
BEGIN
    DECLARE pat_id INT;
    
    SELECT PatientID INTO pat_id FROM Appointments WHERE AppointmentID = app_id;
    
    INSERT INTO Invoices (PatientID, InvoiceDate, TotalAmount)
    VALUES (pat_id, CURDATE(), amount);
    
    UPDATE Appointments SET Status = 'Completed' WHERE AppointmentID = app_id;
    
    SELECT LAST_INSERT_ID() AS NewInvoiceID;
END //
DELIMITER ;

-- Function to calculate total revenue
DELIMITER //
CREATE FUNCTION fn_CalculateTotalRevenue(start_date DATE, end_date DATE) 
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE total DECIMAL(10,2);
    
    SELECT SUM(TotalAmount) INTO total
    FROM Invoices
    WHERE InvoiceDate BETWEEN start_date AND end_date
    AND Status = 'Paid';
    
    RETURN IFNULL(total, 0);
END //
DELIMITER ;

-- Trigger to prevent double booking of doctors
DELIMITER //
CREATE TRIGGER trg_PreventDoubleBooking
BEFORE INSERT ON Appointments
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM Appointments
        WHERE DoctorID = NEW.DoctorID
        AND AppointmentDate = NEW.AppointmentDate
        AND AppointmentTime = NEW.AppointmentTime
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Doctor already has an appointment at this time';
    END IF;
END //
DELIMITER ;
